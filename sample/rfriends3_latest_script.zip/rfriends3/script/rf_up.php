<?php
 require_once("rf_upd_common.php"); require_once("rf_upd_system.php"); require_once("rf_up_inc.php"); $rfriends_mes = "ラジオ録音ツール"; rfmenu_update_sub($upty); 